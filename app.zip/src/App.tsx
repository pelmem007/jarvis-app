import { useCallback, useEffect, useRef, useState } from 'react';
import { MessageSquareText, Database, ListChecks, Radar, Settings as SettingsIcon } from 'lucide-react';
import Assistant from '@/sections/Assistant';
import Knowledge from '@/sections/Knowledge';
import Planner from '@/sections/Planner';
import SystemPanel from '@/sections/SystemPanel';
import SettingsPanel from '@/sections/SettingsPanel';
import { db, initDb, loadSettings, type Reminder, type Settings } from '@/lib/db';
import { useDeviceInfo } from '@/hooks/useDevice';
import { speak } from '@/hooks/useSpeech';
import { randomFact } from '@/lib/engine';

type Tab = 'assistant' | 'knowledge' | 'planner' | 'system' | 'settings';

const NAV: { key: Tab; label: string; icon: React.ReactNode }[] = [
  { key: 'assistant', label: 'Ассистент', icon: <MessageSquareText size={20} /> },
  { key: 'knowledge', label: 'База', icon: <Database size={20} /> },
  { key: 'planner', label: 'Планнер', icon: <ListChecks size={20} /> },
  { key: 'system', label: 'Система', icon: <Radar size={20} /> },
  { key: 'settings', label: 'Настройки', icon: <SettingsIcon size={20} /> },
];

function beep() {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    [880, 1174, 1568].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + i * 0.18);
      gain.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + i * 0.18 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.18 + 0.16);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.18);
      osc.stop(ctx.currentTime + i * 0.18 + 0.2);
    });
  } catch {
    /* тихо */
  }
}

export default function App() {
  const [tab, setTab] = useState<Tab>('assistant');
  const [settings, setSettings] = useState<Settings | null>(null);
  const device = useDeviceInfo();
  const addChatMessageRef = useRef<(text: string) => void>(() => undefined);
  const [tickerFact, setTickerFact] = useState(() => randomFact().text);

  useEffect(() => {
    void (async () => {
      await initDb();
      setSettings(await loadSettings());
    })();
    // запрос разрешения на уведомления по первому касанию
    const ask = () => {
      if ('Notification' in window && Notification.permission === 'default') {
        void Notification.requestPermission();
      }
      window.removeEventListener('pointerdown', ask);
    };
    window.addEventListener('pointerdown', ask);
    return () => window.removeEventListener('pointerdown', ask);
  }, []);

  // ротация факта в тикере
  useEffect(() => {
    const iv = setInterval(() => setTickerFact(randomFact().text), 15000);
    return () => clearInterval(iv);
  }, []);

  // планировщик напоминаний — раз в секунду, локально
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  useEffect(() => {
    const iv = setInterval(async () => {
      const now = Date.now();
      const due = (await db.getAll<Reminder>('reminders')).filter((r) => !r.fired && r.at <= now);
      for (const r of due) {
        await db.put('reminders', { ...r, fired: true });
        const text = `Напоминание: ${r.text}`;
        beep();
        addChatMessageRef.current(text);
        if (settingsRef.current) speak(text, settingsRef.current);
        if ('Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification('JARVIS', { body: r.text, tag: `rem-${r.id}` });
          } catch {
            /* тихо */
          }
        }
      }
    }, 1000);
    return () => clearInterval(iv);
  }, []);

  const registerMessageAdder = useCallback((fn: (text: string) => void) => {
    addChatMessageRef.current = fn;
  }, []);

  if (!settings) {
    return (
      <div className="flex h-[100dvh] items-center justify-center bg-[#050810]">
        <div className="text-center">
          <div className="anim-ring-pulse mx-auto mb-4 h-14 w-14 rounded-full border-2 border-[#22d3ee]" />
          <p className="hud-label">Загрузка систем…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-[100dvh] bg-[#050810] text-[#dbe7f4]">
      {/* боковая панель (десктоп) */}
      <aside className="hidden w-60 shrink-0 flex-col border-r border-[#1a2540] bg-[#070c16] lg:flex">
        <Logo />
        <nav className="flex-1 space-y-1 px-3 py-4">
          {NAV.map((n) => (
            <button
              key={n.key}
              onClick={() => setTab(n.key)}
              className={`flex min-h-[44px] w-full items-center gap-3 rounded-lg px-3 text-sm transition-colors ${
                tab === n.key ? 'bg-[#0e2a33] text-[#22d3ee]' : 'text-[#9fb4cc] hover:bg-[#0c1220]'
              }`}
            >
              {n.icon}
              {n.label}
            </button>
          ))}
        </nav>
        <div className="border-t border-[#1a2540] p-4">
          <p className="text-[10px] leading-relaxed text-[#4a5d78]">
            JARVIS v1.0<br />Автономный режим · данные на устройстве
          </p>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* шапка */}
        <header className="border-b border-[#1a2540] bg-[#070c16]/90">
          <div className="flex items-center justify-between px-3 py-2 sm:px-5">
            <div className="lg:hidden"><Logo compact /></div>
            <div className="hidden items-center gap-3 lg:flex">
              <Led on={device.online} color="#34d399" label="NET" />
              <Led on={settings.voiceOn} color="#22d3ee" label="VOICE" />
              <Led on color="#e879f9" label="DB" />
              <Led on={device.battery !== null} color="#fbbf24" label="BAT" />
            </div>
            <p className="text-xs tabular-nums text-[#7d93b2]">
              {new Date().toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })}{' '}
              <Clock />
            </p>
          </div>
          {/* тикер */}
          <div className="overflow-hidden border-t border-[#1a2540]/60 py-1">
            <div
              className="whitespace-nowrap text-[10px] uppercase tracking-[0.18em] text-[#4a5d78]"
              style={{ animation: 'tickerScroll 60s linear infinite' }}
            >
              <span className="mx-8">◈ {tickerFact}</span>
              <span className="mx-8">◈ {tickerFact}</span>
            </div>
          </div>
        </header>

        {/* контент */}
        <main className="min-h-0 flex-1">
          {tab === 'assistant' && (
            <Assistant settings={settings} device={device} onNavigate={setTab} registerMessageAdder={registerMessageAdder} />
          )}
          {tab === 'knowledge' && <Knowledge />}
          {tab === 'planner' && <Planner />}
          {tab === 'system' && <SystemPanel device={device} />}
          {tab === 'settings' && <SettingsPanel settings={settings} onChange={setSettings} />}
        </main>

        {/* нижняя навигация (мобайл) */}
        <nav
          className="grid grid-cols-5 border-t border-[#1a2540] bg-[#070c16]/95 lg:hidden"
          style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
        >
          {NAV.map((n) => (
            <button
              key={n.key}
              onClick={() => setTab(n.key)}
              className={`flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[9px] uppercase tracking-wider transition-colors ${
                tab === n.key ? 'text-[#22d3ee]' : 'text-[#5b7089]'
              }`}
            >
              <span className={tab === n.key ? 'drop-shadow-[0_0_6px_rgba(34,211,238,.8)]' : ''}>{n.icon}</span>
              {n.label}
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}

function Clock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);
  return <span className="text-[#dbe7f4]">{now.toLocaleTimeString('ru-RU')}</span>;
}

function Led({ on, color, label }: { on: boolean; color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span
        className={`h-2 w-2 rounded-full ${on ? 'anim-pulse-dot' : ''}`}
        style={{ background: on ? color : '#1a2540' }}
      />
      <span className="text-[9px] uppercase tracking-[0.2em] text-[#4a5d78]">{label}</span>
    </span>
  );
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`flex items-center gap-2.5 ${compact ? '' : 'px-5 py-4'}`}>
      <span className="relative flex h-9 w-9 items-center justify-center">
        <span className="absolute inset-0 rounded-full border border-[#1a2540]" />
        <span className="anim-spin-slow absolute inset-0 rounded-full border border-transparent border-t-[#22d3ee]" />
        <span className="text-sm font-bold text-[#22d3ee]" style={{ textShadow: '0 0 12px rgba(34,211,238,.9)' }}>J</span>
      </span>
      <div className="leading-tight">
        <p className="text-sm font-bold tracking-[0.28em] text-[#e6f1ff]">JARVIS</p>
        <p className="text-[9px] uppercase tracking-[0.22em] text-[#4a5d78]">offline core</p>
      </div>
    </div>
  );
}
