import { useMemo, useState } from 'react';
import { Search, Database, GraduationCap } from 'lucide-react';
import { ALL_FACTS, CATEGORY_META } from '@/data/facts';
import { searchFacts } from '@/lib/engine';

export default function Knowledge() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<string | null>(null);

  const results = useMemo(() => {
    if (query.trim()) return searchFacts(query, 30);
    if (category) return ALL_FACTS.filter((f) => f.category === category);
    return ALL_FACTS;
  }, [query, category]);

  const counts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const f of ALL_FACTS) map[f.category] = (map[f.category] ?? 0) + 1;
    return map;
  }, []);

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-[#1a2540] px-3 pb-3 pt-4 sm:px-6">
        <div className="mb-3 flex items-center gap-2">
          <Database size={16} className="text-[#22d3ee]" />
          <h2 className="hud-label !text-xs">База знаний · {ALL_FACTS.length} записей</h2>
        </div>
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#4a5d78]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск по базе: чёрные дыры, Рим, ДНК…"
            className="h-11 w-full rounded-lg border border-[#1a2540] bg-[#0c1220] pl-9 pr-3 text-sm text-[#dbe7f4] placeholder-[#4a5d78] outline-none focus:border-[#22d3ee]/60"
          />
        </div>
        <div className="mt-2.5 flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
          <button
            onClick={() => { setCategory(null); setQuery(''); }}
            className={`min-h-[36px] shrink-0 rounded-full border px-3.5 text-xs transition-colors ${!category && !query ? 'border-[#22d3ee] text-[#22d3ee]' : 'border-[#1a2540] text-[#9fb4cc]'}`}
          >
            Все
          </button>
          {Object.entries(CATEGORY_META).map(([key, meta]) => (
            <button
              key={key}
              onClick={() => { setCategory(key); setQuery(''); }}
              className="min-h-[36px] shrink-0 rounded-full border px-3.5 text-xs transition-colors"
              style={
                category === key && !query
                  ? { borderColor: meta.color, color: meta.color }
                  : { borderColor: '#1a2540', color: '#9fb4cc' }
              }
            >
              {meta.label} · {counts[key] ?? 0}
            </button>
          ))}
        </div>
      </div>

      <div className="hud-scanlines flex-1 overflow-y-auto px-3 py-4 sm:px-6">
        {results.length === 0 && (
          <div className="mx-auto mt-10 max-w-xs rounded-lg border border-dashed border-[#1a2540] p-6 text-center text-sm text-[#7d93b2]">
            Ничего не найдено. Попробуйте другой запрос — или спросите ассистента, он найдёт ближайшее.
          </div>
        )}
        <div className="mx-auto grid max-w-4xl gap-3 sm:grid-cols-2">
          {results.map((f) => {
            const meta = CATEGORY_META[f.category];
            return (
              <article key={f.id} className="hud-panel msg-in rounded-lg p-4" style={{ borderLeft: `3px solid ${meta?.color ?? '#22d3ee'}` }}>
                <div className="mb-1.5 flex items-center justify-between gap-2">
                  <h3 className="text-sm font-semibold text-[#e6f1ff]">{f.title}</h3>
                  <span className="shrink-0 text-[10px] uppercase tracking-widest" style={{ color: meta?.color }}>
                    {meta?.label}
                  </span>
                </div>
                <p className="text-xs leading-relaxed text-[#9fb4cc]">{f.text}</p>
              </article>
            );
          })}
        </div>
        <div className="mx-auto mt-6 flex max-w-4xl items-center gap-2 pb-4 text-[10px] text-[#4a5d78]">
          <GraduationCap size={12} />
          <span>Показано записей: {results.length}. Все данные встроены в приложение и доступны без сети.</span>
        </div>
      </div>
    </div>
  );
}
