import { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, Circle, Plus, StickyNote, BellRing, ListTodo, Trash2 } from 'lucide-react';
import { db, type Note, type Reminder, type Task } from '@/lib/db';

type Tab = 'tasks' | 'notes' | 'reminders';

export default function Planner() {
  const [tab, setTab] = useState<Tab>('tasks');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [draft, setDraft] = useState('');

  const reload = useCallback(async () => {
    const [t, n, r] = await Promise.all([
      db.getAll<Task>('tasks'),
      db.getAll<Note>('notes'),
      db.getAll<Reminder>('reminders'),
    ]);
    setTasks(t.sort((a, b) => Number(a.done) - Number(b.done) || b.ts - a.ts));
    setNotes(n.sort((a, b) => b.ts - a.ts));
    setReminders(r.filter((x) => !x.fired).sort((a, b) => a.at - b.at));
  }, []);

  useEffect(() => {
    void reload();
    const iv = setInterval(() => void reload(), 5000);
    return () => clearInterval(iv);
  }, [reload]);

  const addItem = async () => {
    const text = draft.trim();
    if (!text) return;
    if (tab === 'tasks') await db.add('tasks', { text, done: false, ts: Date.now() });
    else if (tab === 'notes') await db.add('notes', { text, ts: Date.now() });
    setDraft('');
    await reload();
  };

  const toggleTask = async (task: Task) => {
    await db.put('tasks', { ...task, done: !task.done });
    await reload();
  };

  const TABS: { key: Tab; label: string; icon: React.ReactNode; count: number }[] = [
    { key: 'tasks', label: 'Задачи', icon: <ListTodo size={14} />, count: tasks.filter((t) => !t.done).length },
    { key: 'notes', label: 'Заметки', icon: <StickyNote size={14} />, count: notes.length },
    { key: 'reminders', label: 'Напоминания', icon: <BellRing size={14} />, count: reminders.length },
  ];

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-[#1a2540] px-3 pb-3 pt-4 sm:px-6">
        <div className="mb-3 flex gap-2">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-lg border text-xs transition-colors ${
                tab === t.key ? 'border-[#22d3ee] bg-[#0e2a33]/60 text-[#22d3ee]' : 'border-[#1a2540] text-[#9fb4cc]'
              }`}
            >
              {t.icon}
              {t.label}
              <span className="rounded-full bg-[#1a2540] px-1.5 py-0.5 text-[10px]">{t.count}</span>
            </button>
          ))}
        </div>

        {tab !== 'reminders' && (
          <div className="flex gap-2">
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && void addItem()}
              placeholder={tab === 'tasks' ? 'Новая задача…' : 'Новая заметка…'}
              className="h-11 flex-1 rounded-lg border border-[#1a2540] bg-[#0c1220] px-3 text-sm text-[#dbe7f4] placeholder-[#4a5d78] outline-none focus:border-[#22d3ee]/60"
            />
            <button
              onClick={() => void addItem()}
              className="flex h-11 w-11 items-center justify-center rounded-lg border border-[#22d3ee]/50 bg-[#0e2a33] text-[#22d3ee] active:bg-[#22d3ee] active:text-[#050810]"
            >
              <Plus size={18} />
            </button>
          </div>
        )}
        {tab === 'reminders' && (
          <p className="text-xs leading-relaxed text-[#7d93b2]">
            Напоминания создаются голосом или текстом в чате: «напомни позвонить через 20 минут», «напомни в 18:30», «таймер 5 минут».
          </p>
        )}
      </div>

      <div className="hud-scanlines flex-1 overflow-y-auto px-3 py-4 sm:px-6">
        <div className="mx-auto max-w-2xl space-y-2">
          {tab === 'tasks' && (
            <>
              {tasks.length === 0 && <Empty text="Задач нет. Добавьте выше или скажите ассистенту: «добавь задачу …»." />}
              {tasks.map((task) => (
                <div key={task.id} className="hud-panel flex items-center gap-3 rounded-lg px-3.5 py-3">
                  <button onClick={() => void toggleTask(task)} className="shrink-0 p-1" aria-label="переключить">
                    {task.done ? <CheckCircle2 size={22} className="text-[#34d399]" /> : <Circle size={22} className="text-[#4a5d78]" />}
                  </button>
                  <span className={`flex-1 text-sm ${task.done ? 'text-[#4a5d78] line-through' : 'text-[#dbe7f4]'}`}>{task.text}</span>
                  <button
                    onClick={async () => { if (task.id != null) { await db.delete('tasks', task.id); await reload(); } }}
                    className="shrink-0 p-2 text-[#4a5d78] active:text-[#f87171]"
                    aria-label="удалить"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </>
          )}

          {tab === 'notes' && (
            <>
              {notes.length === 0 && <Empty text="Заметок нет. Скажите ассистенту: «заметка: …»." />}
              {notes.map((n) => (
                <div key={n.id} className="hud-panel msg-in rounded-lg border-l-2 !border-l-[#fbbf24] px-3.5 py-3">
                  <p className="text-sm text-[#dbe7f4]">{n.text}</p>
                  <div className="mt-1.5 flex items-center justify-between">
                    <span className="text-[10px] text-[#4a5d78]">
                      {new Date(n.ts).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <button
                      onClick={async () => { if (n.id != null) { await db.delete('notes', n.id); await reload(); } }}
                      className="p-1.5 text-[#4a5d78] active:text-[#f87171]"
                      aria-label="удалить"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </>
          )}

          {tab === 'reminders' && (
            <>
              {reminders.length === 0 && <Empty text="Активных напоминаний нет." />}
              {reminders.map((r) => {
                const left = r.at - Date.now();
                const leftLabel = left <= 0 ? 'сейчас' : formatLeft(left);
                return (
                  <div key={r.id} className="hud-panel flex items-center gap-3 rounded-lg border-l-2 !border-l-[#e879f9] px-3.5 py-3">
                    <BellRing size={18} className="shrink-0 text-[#e879f9]" />
                    <div className="flex-1">
                      <p className="text-sm text-[#dbe7f4]">{r.text}</p>
                      <p className="text-[10px] text-[#4a5d78]">
                        {new Date(r.at).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} · через {leftLabel}
                      </p>
                    </div>
                    <button
                      onClick={async () => { if (r.id != null) { await db.delete('reminders', r.id); await reload(); } }}
                      className="shrink-0 p-2 text-[#4a5d78] active:text-[#f87171]"
                      aria-label="удалить"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                );
              })}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="rounded-lg border border-dashed border-[#1a2540] p-6 text-center text-sm text-[#7d93b2]">{text}</div>
  );
}

function formatLeft(ms: number): string {
  const min = Math.round(ms / 60000);
  if (min < 1) return 'меньше минуты';
  if (min < 60) return `${min} мин`;
  const h = Math.floor(min / 60);
  return `${h} ч ${min % 60} мин`;
}
