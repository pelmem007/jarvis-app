import { useEffect, useState } from 'react';
import { BatteryCharging, Cpu, HardDrive, MonitorSmartphone, Wifi, WifiOff, Clock3, Database } from 'lucide-react';
import type { DeviceInfo } from '@/lib/engine';
import { db } from '@/lib/db';

interface Props {
  device: DeviceInfo & { bootTime: number };
}

export default function SystemPanel({ device }: Props) {
  const [now, setNow] = useState(Date.now());
  const [dbStats, setDbStats] = useState<{ name: string; count: number }[]>([]);

  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    const load = async () => {
      const names = [
        ['messages', 'Сообщения'],
        ['notes', 'Заметки'],
        ['tasks', 'Задачи'],
        ['reminders', 'Напоминания'],
        ['learnedFacts', 'Выученное'],
      ] as const;
      const rows = await Promise.all(names.map(async ([store, label]) => ({ name: label, count: await db.count(store) })));
      setDbStats(rows);
    };
    void load();
    const iv = setInterval(() => void load(), 5000);
    return () => clearInterval(iv);
  }, []);

  const uptime = Math.floor((now - device.bootTime) / 1000);
  const batt = device.battery;

  return (
    <div className="hud-scanlines flex-1 overflow-y-auto px-3 py-4 sm:px-6">
      <div className="mx-auto max-w-2xl space-y-3">
        {/* радар + часы */}
        <div className="hud-panel hud-glow-cyan relative overflow-hidden rounded-xl p-5">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="hud-label">Системное время</p>
              <p className="mt-1 text-3xl font-bold tabular-nums tracking-wider text-[#e6f1ff]">
                {new Date(now).toLocaleTimeString('ru-RU')}
              </p>
              <p className="mt-0.5 text-xs text-[#7d93b2]">
                {new Date(now).toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
              <p className="mt-2 text-[10px] uppercase tracking-widest text-[#4a5d78]">
                Аптайм сессии: {Math.floor(uptime / 60)}:{String(uptime % 60).padStart(2, '0')}
              </p>
            </div>
            {/* радар */}
            <div className="relative h-28 w-28 shrink-0">
              <div className="absolute inset-0 rounded-full border border-[#1a2540]" />
              <div className="absolute inset-[18%] rounded-full border border-[#1a2540]" />
              <div className="absolute inset-[36%] rounded-full border border-[#1a2540]" />
              <div className="absolute inset-x-1/2 inset-y-0 w-px bg-[#1a2540]" />
              <div className="absolute inset-x-0 inset-y-1/2 h-px bg-[#1a2540]" />
              <div
                className="anim-radar-sweep absolute inset-0 rounded-full"
                style={{ background: 'conic-gradient(from 0deg, rgba(34,211,238,.45), transparent 70deg, transparent)' }}
              />
              <div className="anim-pulse-dot absolute left-[30%] top-[38%] h-1.5 w-1.5 rounded-full bg-[#22d3ee]" />
              <div className="anim-pulse-dot absolute left-[62%] top-[64%] h-1.5 w-1.5 rounded-full bg-[#34d399]" style={{ animationDelay: '.5s' }} />
              <div className="anim-pulse-dot absolute left-[70%] top-[26%] h-1.5 w-1.5 rounded-full bg-[#fbbf24]" style={{ animationDelay: '1s' }} />
            </div>
          </div>
        </div>

        {/* батарея и сеть */}
        <div className="grid grid-cols-2 gap-3">
          <div className="hud-panel rounded-xl p-4">
            <div className="mb-2 flex items-center gap-2">
              <BatteryCharging size={14} className="text-[#34d399]" />
              <span className="hud-label">Батарея</span>
            </div>
            <div className="flex items-end gap-2">
              <span className="text-3xl font-bold tabular-nums text-[#e6f1ff]">
                {batt === null ? '—' : `${Math.round(batt)}`}
              </span>
              <span className="pb-1 text-xs text-[#7d93b2]">{batt === null ? 'н/д' : '%'}</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#1a2540]">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: batt === null ? '0%' : `${batt}%`,
                  background: batt !== null && batt < 20 ? '#f87171' : batt !== null && batt < 50 ? '#fbbf24' : '#34d399',
                }}
              />
            </div>
            <p className="mt-1.5 text-[10px] text-[#4a5d78]">
              {device.charging === null ? 'Статус недоступен' : device.charging ? 'Идёт зарядка' : 'От батареи'}
            </p>
          </div>

          <div className="hud-panel rounded-xl p-4">
            <div className="mb-2 flex items-center gap-2">
              {device.online ? <Wifi size={14} className="text-[#22d3ee]" /> : <WifiOff size={14} className="text-[#fbbf24]" />}
              <span className="hud-label">Сеть</span>
            </div>
            <p className="text-lg font-semibold text-[#e6f1ff]">{device.online ? 'Онлайн' : 'Офлайн'}</p>
            <p className="mt-1 text-[10px] leading-relaxed text-[#4a5d78]">
              {device.online ? 'Связь есть, но JARVIS в ней не нуждается' : 'Нет сети — JARVIS продолжает работать на 100%'}
            </p>
          </div>
        </div>

        {/* железо */}
        <div className="hud-panel rounded-xl p-4">
          <div className="mb-3 flex items-center gap-2">
            <Cpu size={14} className="text-[#22d3ee]" />
            <span className="hud-label">Устройство</span>
          </div>
          <dl className="space-y-2 text-xs">
            <Row k="Платформа" v={device.platform} icon={<MonitorSmartphone size={12} />} />
            <Row k="Экран" v={device.screen} icon={<MonitorSmartphone size={12} />} />
            <Row k="Ядер CPU" v={device.cores !== null ? String(device.cores) : 'н/д'} icon={<Cpu size={12} />} />
            <Row k="ОЗУ (оценка)" v={device.memoryGB !== null ? `~${device.memoryGB} ГБ` : 'н/д'} icon={<Cpu size={12} />} />
            <Row k="Хранилище" v={device.storageUsed ?? 'н/д'} icon={<HardDrive size={12} />} />
            <Row k="Язык" v={device.language} icon={<Clock3 size={12} />} />
          </dl>
        </div>

        {/* база данных */}
        <div className="hud-panel rounded-xl p-4">
          <div className="mb-3 flex items-center gap-2">
            <Database size={14} className="text-[#e879f9]" />
            <span className="hud-label">Локальная база данных</span>
          </div>
          <div className="space-y-2">
            {dbStats.map((s) => (
              <div key={s.name} className="flex items-center gap-3">
                <span className="w-28 shrink-0 text-xs text-[#9fb4cc]">{s.name}</span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#1a2540]">
                  <div
                    className="h-full rounded-full bg-[#e879f9]/70 transition-all duration-500"
                    style={{ width: `${Math.min(100, (s.count / Math.max(1, ...dbStats.map((x) => x.count))) * 100)}%` }}
                  />
                </div>
                <span className="w-10 text-right text-xs tabular-nums text-[#e6f1ff]">{s.count}</span>
              </div>
            ))}
          </div>
          <p className="mt-3 text-[10px] text-[#4a5d78]">
            IndexedDB внутри устройства. Данные не покидают телефон.
          </p>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v, icon }: { k: string; v: string; icon: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-[#1a2540]/60 pb-2 last:border-0 last:pb-0">
      <dt className="flex items-center gap-2 text-[#7d93b2]">{icon}{k}</dt>
      <dd className="text-[#e6f1ff]">{v}</dd>
    </div>
  );
}
