import { useRef, useState } from 'react';
import { Volume2, VolumeX, User, Download, Upload, Trash2, Info } from 'lucide-react';
import { exportAll, importAll, saveSettings, wipeAll, type Settings } from '@/lib/db';
import { speak, useVoices } from '@/hooks/useSpeech';

interface Props {
  settings: Settings;
  onChange: (s: Settings) => void;
}

export default function SettingsPanel({ settings, onChange }: Props) {
  const voices = useVoices();
  const fileRef = useRef<HTMLInputElement>(null);
  const [msg, setMsg] = useState('');

  const patch = async (p: Partial<Settings>) => {
    const next = { ...settings, ...p };
    await saveSettings(p);
    onChange(next);
  };

  const flash = (text: string) => {
    setMsg(text);
    setTimeout(() => setMsg(''), 3000);
  };

  return (
    <div className="hud-scanlines flex-1 overflow-y-auto px-3 py-4 sm:px-6">
      <div className="mx-auto max-w-2xl space-y-3 pb-6">
        {/* голос */}
        <div className="hud-panel rounded-xl p-4">
          <div className="mb-3 flex items-center gap-2">
            {settings.voiceOn ? <Volume2 size={14} className="text-[#22d3ee]" /> : <VolumeX size={14} className="text-[#7d93b2]" />}
            <span className="hud-label">Голосовой вывод</span>
          </div>

          <label className="flex min-h-[44px] items-center justify-between">
            <span className="text-sm text-[#dbe7f4]">Озвучивать ответы</span>
            <button
              onClick={() => void patch({ voiceOn: !settings.voiceOn })}
              className={`relative h-7 w-12 rounded-full transition-colors ${settings.voiceOn ? 'bg-[#22d3ee]' : 'bg-[#1a2540]'}`}
              aria-label="переключить голос"
            >
              <span
                className="absolute top-1 h-5 w-5 rounded-full bg-white transition-all"
                style={{ left: settings.voiceOn ? '26px' : '4px' }}
              />
            </button>
          </label>

          <div className="mt-3 space-y-3">
            <div>
              <div className="mb-1 flex justify-between text-xs text-[#7d93b2]">
                <span>Скорость речи</span><span className="tabular-nums text-[#e6f1ff]">{settings.voiceRate.toFixed(1)}×</span>
              </div>
              <input
                type="range" min={0.5} max={1.5} step={0.1} value={settings.voiceRate}
                onChange={(e) => void patch({ voiceRate: parseFloat(e.target.value) })}
                className="w-full accent-[#22d3ee]"
              />
            </div>
            <div>
              <div className="mb-1 flex justify-between text-xs text-[#7d93b2]">
                <span>Тон голоса</span><span className="tabular-nums text-[#e6f1ff]">{settings.voicePitch.toFixed(1)}</span>
              </div>
              <input
                type="range" min={0.5} max={1.5} step={0.1} value={settings.voicePitch}
                onChange={(e) => void patch({ voicePitch: parseFloat(e.target.value) })}
                className="w-full accent-[#22d3ee]"
              />
            </div>
            {voices.length > 0 && (
              <div>
                <p className="mb-1 text-xs text-[#7d93b2]">Голос</p>
                <select
                  value={settings.voiceName}
                  onChange={(e) => void patch({ voiceName: e.target.value })}
                  className="h-11 w-full rounded-lg border border-[#1a2540] bg-[#0c1220] px-3 text-sm text-[#dbe7f4] outline-none"
                >
                  <option value="">Системный по умолчанию</option>
                  {voices.map((v) => (
                    <option key={v.name} value={v.name}>{v.name}</option>
                  ))}
                </select>
              </div>
            )}
            <button
              onClick={() => speak('Проверка голоса. Все системы Джарвис работают нормально.', { ...settings, voiceOn: true })}
              className="min-h-[44px] w-full rounded-lg border border-[#22d3ee]/50 text-sm text-[#22d3ee] active:bg-[#0e2a33]"
            >
              Проверить голос
            </button>
          </div>
        </div>

        {/* профиль */}
        <div className="hud-panel rounded-xl p-4">
          <div className="mb-3 flex items-center gap-2">
            <User size={14} className="text-[#34d399]" />
            <span className="hud-label">Профиль</span>
          </div>
          <p className="mb-1 text-xs text-[#7d93b2]">Как к вам обращаться</p>
          <input
            defaultValue={settings.userName}
            onBlur={(e) => void patch({ userName: e.target.value.trim() })}
            placeholder="Ваше имя…"
            className="h-11 w-full rounded-lg border border-[#1a2540] bg-[#0c1220] px-3 text-sm text-[#dbe7f4] placeholder-[#4a5d78] outline-none focus:border-[#22d3ee]/60"
          />
        </div>

        {/* данные */}
        <div className="hud-panel rounded-xl p-4">
          <div className="mb-3 flex items-center gap-2">
            <Download size={14} className="text-[#fbbf24]" />
            <span className="hud-label">Данные</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={async () => {
                const json = await exportAll();
                const blob = new Blob([json], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'jarvis-backup.json';
                a.click();
                URL.revokeObjectURL(url);
                flash('Резервная копия сохранена в файл.');
              }}
              className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-[#1a2540] text-xs text-[#dbe7f4] active:border-[#22d3ee]"
            >
              <Download size={14} /> Экспорт
            </button>
            <button
              onClick={() => fileRef.current?.click()}
              className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-[#1a2540] text-xs text-[#dbe7f4] active:border-[#22d3ee]"
            >
              <Upload size={14} /> Импорт
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json"
              className="hidden"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                try {
                  await importAll(await file.text());
                  flash('Данные восстановлены из файла.');
                } catch {
                  flash('Ошибка: файл повреждён или не является копией JARVIS.');
                }
                e.target.value = '';
              }}
            />
            <button
              onClick={async () => {
                if (window.confirm('Удалить ВСЕ данные JARVIS: чат, задачи, заметки, выученные ответы?')) {
                  await wipeAll();
                  flash('Все данные удалены.');
                }
              }}
              className="col-span-2 flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-[#f87171]/40 text-xs text-[#f87171] active:bg-[#f87171]/10"
            >
              <Trash2 size={14} /> Полный сброс
            </button>
          </div>
          {msg && <p className="mt-2 text-center text-xs text-[#34d399]">{msg}</p>}
        </div>

        {/* о программе */}
        <div className="hud-panel rounded-xl p-4">
          <div className="mb-2 flex items-center gap-2">
            <Info size={14} className="text-[#7d93b2]" />
            <span className="hud-label">О системе</span>
          </div>
          <p className="text-xs leading-relaxed text-[#9fb4cc]">
            JARVIS · версия 1.0 · полностью автономный ассистент. Движок команд, база знаний, калькулятор,
            конвертер, планировщик и игры работают без сети. Установите на главный экран из меню браузера —
            и я буду как родное приложение.
          </p>
        </div>
      </div>
    </div>
  );
}
