import { useCallback, useEffect, useRef, useState } from 'react';
import { Mic, MicOff, SendHorizonal, Trash2 } from 'lucide-react';
import { db, type ChatMessage, type Settings } from '@/lib/db';
import { respond, type DeviceInfo, type EngineResult } from '@/lib/engine';
import { speak, stopSpeaking, useSpeechRecognition } from '@/hooks/useSpeech';

const CHIPS = [
  'Помощь',
  'Расскажи факт',
  'Шутка',
  'Который час',
  'Таймер 5 минут',
  'Факт о космосе',
  'Игра угадай число',
  'Заряд батареи',
];

interface Props {
  settings: Settings;
  device: DeviceInfo;
  onNavigate: (tab: 'assistant' | 'knowledge' | 'planner' | 'system' | 'settings') => void;
  registerMessageAdder: (fn: (text: string) => void) => void;
}

export default function Assistant({ settings, device, onNavigate, registerMessageAdder }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const deviceRef = useRef(device);
  deviceRef.current = device;

  const scrollDown = useCallback(() => {
    requestAnimationFrame(() => {
      listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
    });
  }, []);

  useEffect(() => {
    db.getAll<ChatMessage>('messages').then((rows) => {
      setMessages(rows.sort((a, b) => a.ts - b.ts).slice(-100));
      scrollDown();
    });
  }, [scrollDown]);

  const pushMessage = useCallback(
    async (role: 'user' | 'jarvis', text: string) => {
      const msg: ChatMessage = { role, text, ts: Date.now() };
      const id = await db.add('messages', msg);
      setMessages((prev) => [...prev.slice(-99), { ...msg, id }]);
      scrollDown();
    },
    [scrollDown],
  );

  // внешние сообщения (напоминания)
  useEffect(() => {
    registerMessageAdder((text: string) => {
      void pushMessage('jarvis', text);
    });
  }, [registerMessageAdder, pushMessage]);

  const handleResult = useCallback(
    (result: EngineResult) => {
      void pushMessage('jarvis', result.text);
      if (result.speak !== false) speak(result.text.replace(/[▸•]/g, ''), settingsRef.current);
      if (result.nav) setTimeout(() => onNavigate(result.nav!), 600);
    },
    [pushMessage, onNavigate],
  );

  const send = useCallback(
    async (text: string) => {
      const clean = text.trim();
      if (!clean) return;
      stopSpeaking();
      setInput('');
      await pushMessage('user', clean);
      setTyping(true);
      const startedAt = Date.now();
      try {
        const result = await respond(clean, { settings: settingsRef.current, device: deviceRef.current });
        const delay = Math.max(0, 420 - (Date.now() - startedAt));
        setTimeout(() => {
          setTyping(false);
          handleResult(result);
        }, delay);
      } catch {
        setTyping(false);
        void pushMessage('jarvis', 'Произошла ошибка обработки. Попробуйте иначе.');
      }
    },
    [pushMessage, handleResult],
  );

  const { supported, listening, start, stop } = useSpeechRecognition((text) => void send(text));

  const clearChat = async () => {
    await db.clear('messages');
    setMessages([]);
  };

  return (
    <div className="flex h-full flex-col">
      {/* лента сообщений */}
      <div ref={listRef} className="hud-scanlines flex-1 space-y-3 overflow-y-auto px-3 py-4 sm:px-6">
        {messages.length === 0 && (
          <div className="mx-auto mt-8 max-w-sm text-center">
            <div className="relative mx-auto mb-5 h-24 w-24">
              <div className="absolute inset-0 rounded-full border border-[#1a2540]" />
              <div className="anim-ring-pulse absolute inset-0 rounded-full border border-[#22d3ee]/40" />
              <div className="absolute inset-3 rounded-full border border-[#22d3ee]/30" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold tracking-widest text-[#22d3ee]" style={{ textShadow: '0 0 18px rgba(34,211,238,.8)' }}>
                  J
                </span>
              </div>
            </div>
            <p className="text-sm text-[#7d93b2]">
              Я — JARVIS, офлайн-ассистент. Всё хранится локально, интернет не нужен.
            </p>
            <p className="mt-1 text-xs text-[#4a5d78]">Скажите «помощь», чтобы увидеть все команды.</p>
          </div>
        )}

        {messages.map((m) => (
          <div key={m.id ?? m.ts} className={`msg-in flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={
                m.role === 'user'
                  ? 'max-w-[85%] rounded-lg rounded-br-none border border-[#22d3ee]/40 bg-[#0e2a33]/70 px-3.5 py-2.5 text-sm text-[#d9f6fd]'
                  : 'max-w-[85%] rounded-lg rounded-bl-none border-l-2 border-[#22d3ee] bg-[#0c1220]/90 px-3.5 py-2.5 text-sm text-[#dbe7f4]'
              }
            >
              <p className="whitespace-pre-wrap leading-relaxed">{m.text}</p>
              <p className="mt-1 text-right text-[10px] text-[#4a5d78]">
                {new Date(m.ts).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}

        {typing && (
          <div className="flex justify-start">
            <div className="rounded-lg border-l-2 border-[#22d3ee] bg-[#0c1220]/90 px-4 py-3">
              <span className="typing-dots"><span /><span /><span /></span>
            </div>
          </div>
        )}
      </div>

      {/* быстрые команды */}
      <div className="flex gap-2 overflow-x-auto px-3 pb-2 sm:px-6" style={{ scrollbarWidth: 'none' }}>
        {CHIPS.map((c) => (
          <button
            key={c}
            onClick={() => void send(c)}
            className="min-h-[36px] shrink-0 rounded-full border border-[#1a2540] bg-[#0c1220] px-3.5 text-xs text-[#9fb4cc] transition-colors active:border-[#22d3ee] active:text-[#22d3ee]"
          >
            {c}
          </button>
        ))}
      </div>

      {/* ввод */}
      <div
        className="border-t border-[#1a2540] bg-[#070c16]/95 px-3 pt-2.5 sm:px-6"
        style={{ paddingBottom: 'max(10px, env(safe-area-inset-bottom))' }}
      >
        <div className="mx-auto flex max-w-3xl items-center gap-2">
          <button
            onClick={clearChat}
            title="Очистить чат"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-[#1a2540] text-[#7d93b2] transition-colors active:border-[#f87171] active:text-[#f87171]"
          >
            <Trash2 size={18} />
          </button>

          <div className="relative flex-1">
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && void send(input)}
              placeholder={listening ? 'Слушаю…' : 'Команда или вопрос…'}
              className="h-11 w-full rounded-lg border border-[#1a2540] bg-[#0c1220] pl-3.5 pr-3 text-sm text-[#dbe7f4] placeholder-[#4a5d78] outline-none focus:border-[#22d3ee]/60"
            />
            {listening && <span className="anim-pulse-dot-red absolute right-3 top-1/2 h-2 w-2 -translate-y-1/2 rounded-full bg-[#f87171]" />}
          </div>

          <button
            onClick={() => (listening ? stop() : start())}
            disabled={!supported}
            title={supported ? 'Голосовой ввод' : 'Голосовой ввод недоступен в этом браузере'}
            className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border transition-colors disabled:opacity-30"
            style={{
              borderColor: listening ? '#f87171' : '#1a2540',
              color: listening ? '#f87171' : '#22d3ee',
            }}
          >
            {listening && (
              <>
                <span className="anim-ring-pulse absolute inset-0 rounded-lg border border-[#f87171]/50" />
                <span className="anim-ring-pulse absolute inset-0 rounded-lg border border-[#f87171]/30" style={{ animationDelay: '0.6s' }} />
              </>
            )}
            {listening ? <MicOff size={18} /> : <Mic size={18} />}
          </button>

          <button
            onClick={() => void send(input)}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-[#22d3ee]/50 bg-[#0e2a33] text-[#22d3ee] transition-colors active:bg-[#22d3ee] active:text-[#050810]"
          >
            <SendHorizonal size={18} />
          </button>
        </div>
        <p className="mx-auto mt-1.5 max-w-3xl text-center text-[10px] tracking-wide text-[#3a4a62]">
          100% офлайн · данные хранятся только на этом устройстве
        </p>
      </div>
    </div>
  );
}
